# @warriorpy/cli

> WarriorPY command line.

## Install

```sh
pip install @warriorjs/cli
```

## Usage

```sh
warriorpy
```

For more in depth documentation see: https://warrior.js.org/docs/cli-options.
