class Player(object):
    def play_turn(self, warrior):
        return None  # Your code here
