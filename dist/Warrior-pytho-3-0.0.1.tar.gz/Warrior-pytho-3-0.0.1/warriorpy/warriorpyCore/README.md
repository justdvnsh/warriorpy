# @warriorpy/core

> WarriorPY core.

## Install

```sh
pip install @warriorjs/core
```

## Usage

```py
import @warriorpy/core as core
```
