import unittest
import terminal_screen_size

class TestTerminalScreenSizeMethod(unittest.TestCase):

    def test_rows_columns(self):
        

if __name__ == '__main__':
    unittest.main()