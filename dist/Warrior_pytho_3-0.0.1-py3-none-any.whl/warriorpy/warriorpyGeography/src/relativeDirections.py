FORWARD = 'forward'
RIGHT = 'right'
BACKWARD = 'backword'
LEFT = 'left'

RELATIVE_DIRECTIONS = [FORWARD, RIGHT, BACKWARD, LEFT]