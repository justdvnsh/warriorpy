NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'

# /**
#  * The absolute directions in clockwise order.
#  */

ABSOLUTE_DIRECTIONS = [NORTH, EAST, SOUTH, WEST]